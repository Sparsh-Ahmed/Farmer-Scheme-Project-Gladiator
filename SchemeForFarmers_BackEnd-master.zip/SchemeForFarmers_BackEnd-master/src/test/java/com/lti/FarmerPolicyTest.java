package com.lti;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.lti.entity.FarmerPolicy;
import com.lti.repository.FarmerPolicyRepoImpl;


@SpringBootTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class FarmerPolicyTest {
	
	@Autowired
	FarmerPolicyRepoImpl farmerPolicyRepoImpl;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Test
    public void savePolicyTest() {
		FarmerPolicy policyObj = new FarmerPolicy();
		policyObj.setName("Raj");
		policyObj.setAccountNo("123456789012");
		policyObj.setCauseofloss("flood");
		policyObj.setCropType("Rabi");
		policyObj.setDateofloss("15/08/2021");
		policyObj.setIfsc("HDFC123");
		policyObj.setPremiumAmount(123);
		policyObj.setSumInsured(160);
		int policyNo = farmerPolicyRepoImpl.savePolicy(policyObj);
		assertThat(policyNo).isNotNull();
		
	} 
	@Test
    public void selectPolicyTest() {
    	
    	int policyNo=123;
        FarmerPolicy farmerPolicy = farmerPolicyRepoImpl.selectPolicy(policyNo);
        assertThat(farmerPolicy).isNotNull();
    	
    	
	}


}
