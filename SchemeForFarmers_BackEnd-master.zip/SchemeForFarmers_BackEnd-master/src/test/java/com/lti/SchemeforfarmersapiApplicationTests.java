package com.lti;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.lti.dto.RegisterDto;
import com.lti.entity.Address;
import com.lti.entity.LandDetails;
import com.lti.entity.User;
import com.lti.repository.UserRepository;
import com.lti.service.UserService;

@SpringBootTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)

class SchemeforfarmersapiApplicationTests {

	@Autowired
	private UserService userServ;
	@Autowired
	private UserRepository userRepo;

	@Test
	void addFarmer() {

		RegisterDto regdto = new RegisterDto();

		User u = new User();
		u.setFullname("rahul");
		u.setRole("Farmer");
		u.setEmail("rahul@gmail.com");
		u.setPhoneno(9004215101L);
		u.setAadharcard(112233445566L);
		u.setAccountNumber(112233445566L);
		u.setPassword("rahul123");
		u.setIfsc_Code("SB000123");
		u.setPancard("GBXPC1234");

		Address addr = new Address();
		addr.setAddressLine1("manjarli");
		addr.setAddressLine2("badlapur east");
		addr.setCity("badlapur");
		addr.setPincode(12201);
		addr.setState("maharashtra");

		LandDetails landdetails = new LandDetails();
		landdetails.setAddress("plot no 2");
		landdetails.setArea(100);
		landdetails.setPincode(421502);

		regdto.setUser(u);
		regdto.setLanddetails(landdetails);
		regdto.setAddress(addr);

		userServ.register(regdto);

		assertThat(userRepo.isUserAvailable("rahul@gmail.com")).isTrue();
	}

	@Test
	void addBidder() {

		RegisterDto regdto = new RegisterDto();

		User u = new User();
		u.setFullname("raj");
		u.setRole("Bidder");
		u.setEmail("raj@gmail.com");
		u.setPhoneno(8805212390L);
		u.setAadharcard(998877665544L);
		u.setAccountNumber(998877665544L);
		u.setPassword("Bidder");
		u.setIfsc_Code("SB123555");
		u.setPancard("GBPSR3896K");

		Address addr = new Address();
		addr.setAddressLine1("Shivaji nagar");
		addr.setAddressLine2("badlapur");
		addr.setCity("badlapur");
		addr.setPincode(12201);
		addr.setState("maharashtra");

		regdto.setUser(u);
		regdto.setAddress(addr);

		userServ.register(regdto);

		assertThat(userRepo.isUserAvailable("raj@gmail.com")).isTrue();
		RegisterDto dto = new RegisterDto();

	}

	@Test
	void loginUser() {

		User SavedUser = userServ.login("rahul@gmail.com", "rahul123");
		assertThat(SavedUser).isNotNull();
	}
}
