package com.lti;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dto.CropDto;
import com.lti.entity.Crop;
import com.lti.repository.CropRepository;
import com.lti.service.CropService;

@SpringBootTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class CropTest {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private CropService cropServ;

	@Autowired
	private CropRepository cropRepo;

	@Test
	void CropAdd() {

		Crop c = new Crop();
		c.setName("Rice");
		c.setCropType("Rabi");
		c.setFertilizerType("Urea");
		c.setQuantity(123);
		c.setSoilPh(7.19);
		c.setBasePrice(208);
		c.setStatus("Sold");
		c.setStartDate(LocalDate.of(2021, 5, 5));
		c.setEndDate(LocalDate.of(2021, 5, 6));

		CropDto dto = new CropDto();
		dto.setCrop(c);
		dto.setFarmerid(1);

		cropServ.register(dto);
		Crop crop = cropRepo.getcropbydetails(1, 123, 208);
		assertThat(crop).isNotNull();
	}
	
	@Test
	public void findbyId() {//find crop
		int id=21;
		Crop crop=new Crop();
		crop= entityManager.find(Crop.class, id);
		assertThat(crop).isNotNull();
	}
	@Test
	public void findSoldCropsbyFarmerId() {
         int id=212;
		List<Crop>crops=new ArrayList<>();
		 crops = entityManager.createQuery("select c from Crop c where c.user.id = :cid and c.status = 'Sold'")
				.setParameter("cid", id).getResultList();
		 assertFalse(crops.isEmpty());
	}
    
    
    @Test
    public void getBasePrice() {
    	int id=215;
		double amt= (Double) entityManager.createQuery("select b.basePrice from Crop b where b.id = :cid")
				.setParameter("cid", id).getSingleResult();
		assertEquals(200, amt);
	}
    
	@Test
	public void getcropbydetails() {
        int farmerid=207;
        int quantity=100;
        double price=20;
        Crop crop=new Crop();
		 crop = (Crop) entityManager
				.createQuery("select c from Crop c where c.user.id = :cid and c.quantity = :q and c.basePrice = :cp")
				.setParameter("cid", farmerid).setParameter("q", quantity).setParameter("cp", price).getSingleResult();
		 assertThat(crop).isNotNull();
	}
    
    
    
    
}
