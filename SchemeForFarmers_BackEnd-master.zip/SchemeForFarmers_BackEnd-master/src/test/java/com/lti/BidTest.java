package com.lti;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dto.PlaceBidDto;
import com.lti.entity.Bid;
import com.lti.entity.User;
import com.lti.repository.UserRepository;
import com.lti.service.BidService;
import com.lti.service.UserService;

@SpringBootTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)

public class BidTest {
	@Autowired
	private UserService userServ;
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private BidService bidServ;

	@PersistenceContext
	private EntityManager entityManager;
	
	@Test
	void addbid() {

		PlaceBidDto dto = new PlaceBidDto();

		dto.setAmount(1000);
		dto.setCropid(12);
		dto.setUserid(1);

		assertThat(bidServ.savebid(dto)).isTrue();

	}
	
	@Test
	public void findBidsByCropId() {
		int id=10;
		List<Bid> bids=new ArrayList<>();
		 bids = entityManager.createQuery("select b from Bid b where b.crop.id = :cid").setParameter("cid", id)
				.getResultList();
		 
		 assertFalse(bids.isEmpty());
	}
	
    
	@Test
	public void findBidderbycropid() {//cropid
		int id=210;
		double amt=1000;
		User user=new User();
		user= (User) entityManager.createQuery("select b.user from Bid b where b.crop.id = :cid and b.amount= :amt")
				.setParameter("cid", id).setParameter("amt", amt).getSingleResult();
		assertThat(user).isNotNull();
	}
	
	
}
