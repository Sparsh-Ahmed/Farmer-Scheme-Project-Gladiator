package com.lti.dto;

public class PolicyDto {
    private int policyno;
    private String causeOfloss;
    private String dateOfLoss;
	public int getPolicyno() {
		return policyno;
	}
	public void setPolicyno(int policyno) {
		this.policyno = policyno;
	}
	public String getCauseOfloss() {
		return causeOfloss;
	}
	public void setCauseOfloss(String causeOfloss) {
		this.causeOfloss = causeOfloss;
	}
	public String getDateOfLoss() {
		return dateOfLoss;
	}
	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}
    
    
    
}
