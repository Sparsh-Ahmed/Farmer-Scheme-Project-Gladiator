package com.lti.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.PolicyDto;
import com.lti.entity.FarmerPolicy;
import com.lti.exception.UserServiceException;
import com.lti.service.FarmerPolicyServiceImpl;
import com.lti.status.Status;

@RestController
@CrossOrigin()
public class FarmerPolicyController {
	
	@Autowired
	FarmerPolicyServiceImpl farmerPolicyServiceImpl;
	
	@PostMapping(path = "/applyPolicy")
	public int ApplyPolicy(@RequestBody FarmerPolicy farmerPolicy ) {
	    	System.out.println(farmerPolicy);
		 return farmerPolicyServiceImpl.savepolicyService(farmerPolicy);
	}
	
	@PostMapping(path = "/claimPolicy")
	public Status claimPolicy(@RequestBody PolicyDto policyDto) {
		try {  
			    System.out.println(policyDto.getPolicyno());
			    String flag=farmerPolicyServiceImpl.selectFarmerPolicyCheck(policyDto.getPolicyno(), policyDto.getCauseOfloss(),policyDto.getDateOfLoss());
		        if(flag!="null") {
		
				Status status = new Status();
				status.setStatus(com.lti.status.Status.StatusType.SUCCESS);
				
				return status;
				}
		        else {
		        	Status status = new Status();
					status.setStatus(com.lti.status.Status.StatusType.FAILURE);
					return status;
		        }
			 
			}
		 catch (UserServiceException e) {
				Status status = new Status();
				status.setStatus(com.lti.status.Status.StatusType.FAILURE);
				return status;
			}
		
		 
	}
	

}
