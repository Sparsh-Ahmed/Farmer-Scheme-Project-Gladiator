package com.lti.controller;

import java.util.List;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.ShowBidsByCropId;
import com.lti.dto.bidsDto;
import com.lti.entity.Admin;
import com.lti.exception.CropServiceException;
import com.lti.exception.UserServiceException;
import com.lti.service.AdminService;
import com.lti.service.BidService;
import com.lti.status.Status;

@RestController
@CrossOrigin
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@PostMapping("/getAdmin")
	public Status getAdmin(@RequestBody Admin admin) {
		try {
			 System.out.println(admin.getId());
			 System.out.println(admin.getPassword());
			if (adminService.verifyAdminService(admin)==true) {
				System.out.println("working..");
				Status status = new Status();
				status.setStatus(com.lti.status.Status.StatusType.SUCCESS);
				status.setMessage("Admin Successful");
				return status;
			} else {
				throw new UserServiceException("Admin Unsucessful");
			}
		} catch (UserServiceException e) {
			Status status = new Status();
			status.setStatus(com.lti.status.Status.StatusType.FAILURE);
			status.setMessage(e.getMessage());
			return status;
		}
	}


}
