package com.lti.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="farmerpolicy")
public class FarmerPolicy {
    
	@Id
	@GeneratedValue
	@Column(name="policyno")
	private int policyNo;
	
	@Column(name="name")
	private String name;
	
	@Column(name="accno")
	private String accountNo; 
	
	@Column(name="ifsc")
	private String ifsc; 
	
	@Column(name="croptype")
	private String cropType; 
	
	@Column(name="suminsured")
	private int sumInsured; 
	
	@Column(name="premiumamount")
	private int premiumAmount; 
	
	@Column(name="causeofloss")
	private String causeofloss;
	
	@Column(name="dateofloss")
	private String dateofloss;

	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getCropType() {
		return cropType;
	}

	public void setCropType(String cropType) {
		this.cropType = cropType;
	}

	public int getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(int sumInsured) {
		this.sumInsured = sumInsured;
	}

	public int getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(int premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public String getCauseofloss() {
		return causeofloss;
	}

	public void setCauseofloss(String causeofloss) {
		this.causeofloss = causeofloss;
	}

	public String getDateofloss() {
		return dateofloss;
	}

	public void setDateofloss(String dateofloss) {
		this.dateofloss = dateofloss;
	}
	
	
	
	
}
