package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.entity.FarmerPolicy;
import com.lti.repository.FarmerPolicyRepoImpl;

@Service
public class FarmerPolicyServiceImpl implements FarmerPolicyService {
	  
	 @Autowired
      FarmerPolicyRepoImpl farmerPolicyRepoImpl;
	@Override
	public int savepolicyService(FarmerPolicy farmerPolicy) {
		   System.out.println(farmerPolicy);
		   return farmerPolicyRepoImpl.savePolicy(farmerPolicy);
		   
		  
		
	}
	@Override
	public String selectFarmerPolicyCheck(int policyNo, String causeOfloss, String dateOfloss) {
		  FarmerPolicy farmerPolicy=farmerPolicyRepoImpl.selectPolicy(policyNo);
		 
		  if(farmerPolicy!=null) {
			  farmerPolicy.setCauseofloss(causeOfloss);
			  farmerPolicy.setDateofloss(dateOfloss);
			   farmerPolicyRepoImpl.updatePolicy(farmerPolicy);
			   
			   return "succesful";
		  }
		  else {
			 
			  
			  return "null";
		  }
		
		
		
	}



}
