package com.lti.service;

import org.springframework.stereotype.Service;

import com.lti.entity.FarmerPolicy;

@Service
public interface FarmerPolicyService {
	public int savepolicyService(FarmerPolicy farmerPolicy) ;
	public String selectFarmerPolicyCheck(int policyNo,String causeOfloss,String dateOfloss);

}
