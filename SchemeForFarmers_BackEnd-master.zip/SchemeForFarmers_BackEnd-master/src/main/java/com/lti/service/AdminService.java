package com.lti.service;

import org.springframework.stereotype.Service;

import com.lti.entity.Admin;

@Service
public interface AdminService {
	
	public boolean verifyAdminService(Admin admin);
}
