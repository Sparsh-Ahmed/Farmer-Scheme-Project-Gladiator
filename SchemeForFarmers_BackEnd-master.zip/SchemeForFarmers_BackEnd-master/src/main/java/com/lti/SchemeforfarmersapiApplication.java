package com.lti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchemeforfarmersapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchemeforfarmersapiApplication.class, args);
		System.out.println("Spring started...");
	}

}
