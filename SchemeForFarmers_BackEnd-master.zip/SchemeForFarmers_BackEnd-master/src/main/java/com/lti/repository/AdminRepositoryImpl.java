package com.lti.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.entity.Admin;
import com.lti.entity.Crop;

@Repository
public class AdminRepositoryImpl implements AdminRepository{
	

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@Transactional
	public boolean verifyAdmin(Admin admin) {
		int id = admin.getId();
		
		
		System.out.println(admin.getPassword());
		Admin ad = entityManager.find(Admin.class, id);
        if(ad==null) {
			  return false;
		}
		System.out.println(ad.getPassword());
		if(ad.getPassword().equals(ad.getPassword())){
			return true;
		}
		else
			return false;
		
	}
	
	

}
