package com.lti.repository;

import org.springframework.stereotype.Repository;

import com.lti.entity.Admin;

@Repository
public interface AdminRepository {
	
	

	boolean verifyAdmin(Admin admin);
}
