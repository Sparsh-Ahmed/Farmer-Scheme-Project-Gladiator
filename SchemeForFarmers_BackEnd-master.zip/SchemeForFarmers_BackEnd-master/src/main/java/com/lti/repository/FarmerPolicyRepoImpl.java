package com.lti.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.entity.FarmerPolicy;

@Repository
public class FarmerPolicyRepoImpl implements FarmerPolicyRepo {
     
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public int savePolicy(FarmerPolicy policyObj) {
		
		System.out.println(policyObj);
		entityManager.persist(policyObj);
		return policyObj.getPolicyNo();
	}

	@Override
	@Transactional
	public FarmerPolicy selectPolicy(int policyNo) {
		
		return entityManager.find(FarmerPolicy.class, policyNo);
	}

	@Override
	@Transactional
	public void updatePolicy(FarmerPolicy policyObj) {
		entityManager.persist(policyObj);
		
	}

}




