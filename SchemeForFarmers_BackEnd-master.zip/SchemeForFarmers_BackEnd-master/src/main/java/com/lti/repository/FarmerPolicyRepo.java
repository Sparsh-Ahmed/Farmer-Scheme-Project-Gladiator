package com.lti.repository;

import org.springframework.stereotype.Repository;

import com.lti.entity.FarmerPolicy;

@Repository
public interface FarmerPolicyRepo {
    int savePolicy(FarmerPolicy policyObj);
     FarmerPolicy selectPolicy(int policyNo);
	 void updatePolicy(FarmerPolicy policyObj);
	
}
