export class Notify{
    cropid:number;
    amount:number;
    baseprice:number;
    cropName:String;
    quantity:number;
    farmerName:String;
    bidderName:String;
}