import { RegistrationStatus } from './../farmerregistration/RegistrationStatus';
import { Notify } from './Notification';
export class NotisDto{

    notification:Notify[];
    status:RegistrationStatus;
}