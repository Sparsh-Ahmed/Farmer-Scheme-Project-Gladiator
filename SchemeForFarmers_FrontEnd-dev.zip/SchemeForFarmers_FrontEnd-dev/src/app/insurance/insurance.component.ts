import { Component, OnInit } from '@angular/core';
import{Insurance } from './insurance'
import{InsurancePolicyService} from '../insurance-policy.service'
import { Router } from '@angular/router';
@Component({
  selector: 'app-insurance',
  templateUrl: './insurance.component.html',
  styleUrls: ['./insurance.component.css']
})
export class InsuranceComponent implements OnInit {
  
  insurance:Insurance=new Insurance();
  constructor(private insuranceService:InsurancePolicyService, private router: Router) { }
  cropTypeList:string[]=["Kharif","Rabi","Commercial"];
  ngOnInit(): void {
  }

  calculate(){

    

    if(this.insurance.cropType.toLowerCase()=="kharif" ||this.insurance.cropType.toLowerCase()=="rabi"||this.insurance.cropType.toLowerCase()=="commercial"){
        if(this.insurance.cropType.toLowerCase()=="kharif"){
        this.insurance.premiumAmount=(102*this.insurance.sumInsured/100);
        }
        if(this.insurance.cropType.toLowerCase()=="rabi"){
          this.insurance.premiumAmount=101.5*this.insurance.sumInsured/100;
          }
        if(this.insurance.cropType.toLowerCase()=="commercial"){
            this.insurance.premiumAmount=105*this.insurance.sumInsured/100;
          }
    }
    else{
            alert("Please Enter valid crop type as mentione in note!");
    }
  }

  apply(){
       this.insurance.causeofloss=null;
       this.insurance.dateofloss=null;
       console.log(this.insurance);
       this.insuranceService.applyPolicy(this.insurance).subscribe(
         data=>{
           console.log(data);
           alert("Application successfull ! Your Policy Number is :"+data+". Please Note it for future Reference");
         }
       );
  }

}
function croptype(croptype: any): String {
  throw new Error('Function not implemented.');
}

