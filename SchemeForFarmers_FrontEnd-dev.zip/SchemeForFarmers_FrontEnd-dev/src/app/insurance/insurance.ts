export class Insurance{
        policyNo:number;
        name:String;
        accountNo:String; 
        ifsc:String; 
        cropType:String; 
        sumInsured:number; 
        premiumAmount:number; 
        causeofloss:String;
        dateofloss:String;
}