import { Crop } from "./crop";

export class cropdto{
    crop: Crop;
    farmerid: number;
}