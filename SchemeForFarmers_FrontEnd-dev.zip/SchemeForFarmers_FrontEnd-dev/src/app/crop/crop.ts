export class Crop{
    name: string;
    quantity:number;
    cropType:string;
    basePrice:number;
    fertilizerType:string;
    status:string;
    soilPh:DoubleRange;
    startDate:Date;
    endDate:Date;
  }
  