export class availablecrop{
    id:number;
    name:string;
    cropType:string;
    fertilizerType:string;
    quantity:number;
    soilPh:number;
    basePrice:number;
    fullname:string;
    endDate:Date;
}