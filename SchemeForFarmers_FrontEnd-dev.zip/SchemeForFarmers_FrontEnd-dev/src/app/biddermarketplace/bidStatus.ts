export class BidStatus{
    status:String;
    message:String;
}
export class Value{
    amount:number;
    status:BidStatus;
}