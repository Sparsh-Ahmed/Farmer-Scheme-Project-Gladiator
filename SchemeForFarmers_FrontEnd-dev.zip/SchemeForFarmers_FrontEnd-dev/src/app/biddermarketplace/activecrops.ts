
import { RegistrationStatus } from "../farmerregistration/RegistrationStatus";
import { availablecrop } from "./availablecrop";

export class activecrops{
    crops: availablecrop[];
    status: RegistrationStatus;
}