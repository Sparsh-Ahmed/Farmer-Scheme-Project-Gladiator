export class LiveBid{

    cropid: number;
    userid:number;
    amount:number;
    
}