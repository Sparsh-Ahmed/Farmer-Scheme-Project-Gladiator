export class LoginStatus{
    
    userId: String;
    name:String;
    status:String;
    message:String;
    role:String;
}