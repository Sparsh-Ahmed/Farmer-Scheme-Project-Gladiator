export class login{

    email:String;
    password:String;

}