import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PolicyDto } from './claim-policy/PolicyDto';
import { Insurance } from './insurance/insurance';

@Injectable({
  providedIn: 'root'
})
export class InsurancePolicyService {
  

  constructor(private http: HttpClient) { }
   applyPolicy(details:Insurance): Observable<any>{
    let url = 'http://localhost:8081/applyPolicy';
    console.log(details);
    return this.http.post<any>(url,details);

  }

  updatePolicy(policyDto:PolicyDto):Observable<any>{
    let url = 'http://localhost:8081/claimPolicy';
    console.log(policyDto);
    return this.http.post<any>(url,policyDto);
  }

}
// const params = new HttpParams()
//   .set('paramName1', value1)
//   .set('paramNmae2', value2);
//    return this.httpClient.get<IMyObject[]>(this.myUrl, {params} ).pipe(
//         tap(data=>console.log('ALL:'+JSON.stringify(data))),
//     catchError(this.handleError));
