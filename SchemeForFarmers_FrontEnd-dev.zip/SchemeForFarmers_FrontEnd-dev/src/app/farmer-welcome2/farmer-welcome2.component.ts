import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-farmer-welcome2',
  templateUrl: './farmer-welcome2.component.html',
  styleUrls: ['./farmer-welcome2.component.css']
})
export class FarmerWelcome2Component implements OnInit {

  constructor() {
    
   }

  ngOnInit(): void {
  }

}
