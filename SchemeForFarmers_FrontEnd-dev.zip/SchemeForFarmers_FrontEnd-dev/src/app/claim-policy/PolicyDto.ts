export class PolicyDto{
    policyno:number;
    causeOfloss:string;
    dateOfLoss:string;
}