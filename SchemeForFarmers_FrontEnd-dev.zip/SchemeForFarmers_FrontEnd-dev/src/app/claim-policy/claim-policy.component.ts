import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InsurancePolicyService } from '../insurance-policy.service';
import {PolicyDto} from './PolicyDto';
@Component({
  selector: 'app-claim-policy',
  templateUrl: './claim-policy.component.html',
  styleUrls: ['./claim-policy.component.css']
})
export class ClaimPolicyComponent implements OnInit {
  policyDto:PolicyDto=new PolicyDto();
   
  constructor(private insurancePolicyService:InsurancePolicyService,private router: Router) { }

  ngOnInit(): void {
  }
  claimPolicy(){
    console.log(this.policyDto);
      this.insurancePolicyService.updatePolicy(this.policyDto).subscribe(
        data=>{
          if(data.status=="SUCCESS"){
           
            alert("Your Policy Claim Successfull..! FUNDS WILL BE TRANSFERRED WITHIN TWO WORKING DAYS.");
            
          
          }else{
           
            alert("Wrong Credential");
          }
        }
      );
  }

}
