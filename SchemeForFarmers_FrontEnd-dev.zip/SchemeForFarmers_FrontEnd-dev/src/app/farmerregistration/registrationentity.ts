
export class Address{

    addressLine1:string;
    addressLine2:string;
    state:string;
    city:string;
    pincode:number; 
  
  }
 export class LandDetails{
    area:number;
    address:string;
    pincode:number;
  
  }

  export class User{
    fullname: string;
    phoneno:number;
    role:String;
    email:string;
    password:string;
    accountNumber:number;
    ifscCode:string;
    Aadharcard:number;
    pancard:string;
    addharfile: File;
    panfile:File;
  }
