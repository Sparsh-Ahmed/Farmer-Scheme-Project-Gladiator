import { Address, LandDetails, User } from './registrationentity';
export class registerFinal{

    user:User = new User();
    address:Address=new Address();
    landdetails: LandDetails= new LandDetails();
    
}