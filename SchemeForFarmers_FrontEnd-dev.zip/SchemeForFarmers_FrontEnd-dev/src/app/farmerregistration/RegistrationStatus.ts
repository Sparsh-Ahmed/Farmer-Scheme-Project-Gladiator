export class RegistrationStatus{
    status:String;
    message:String;
}