import { Address,  User } from './registrationentity';
export class bidderreg{

    user:User = new User();
    address:Address=new Address(); 
    
}